class Comment < ActiveRecord::Base
  attr_accessible :article_id, :body, :email, :name
  
  #associa��es
  belongs_to :article
  
  #valida��es
  validates :name, :email, :body, :presence => true
  validate :article_should_be_published
  
  def article_should_be_published
  
	errors.add(:article_id, "Esse artigo ainda n�o foi publicado") if article && !article.published?
  
  end
end
