class PageController < ApplicationController

  def generic
    respond_to do |format|
      format.html
    end
  end
  
  def ideologia
	generic
  end
  
  def equipe
	generic
  end
  
  def inicio
	generic
  end
  
  end