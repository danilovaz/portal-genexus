# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Portaldevgex::Application.config.secret_token = '38b48e944be46d847d8096d7c3182662541c89c5f109dfa077e94b02bea0169dc8f9fc1b858e3c91fb78b34479480633f4371da16e3d56ce082b4e0618fa12d0'
